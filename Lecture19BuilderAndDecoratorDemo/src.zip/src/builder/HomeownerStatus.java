package builder;

/**
 * Representation of homeowner status.
 */
public enum HomeownerStatus
{
    HOME_OWNER,
    RENTER
}