package builder;

/**
 * Suffix representation.
 */
public enum Suffix
{
    III,
    IV,
    JR,
    SR
}