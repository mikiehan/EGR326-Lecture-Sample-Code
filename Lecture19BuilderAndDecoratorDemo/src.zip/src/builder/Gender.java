package builder;

public enum Gender
{
    FEMALE,
    MALE
}
