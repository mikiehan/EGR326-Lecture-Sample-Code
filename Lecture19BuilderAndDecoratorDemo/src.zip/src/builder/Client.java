//package builder;
//
///**
// * Created by mhan on 4/6/2017.
// */
//public class Client {
//    public static void main(String[] args){
//        final Person person1 = new Person.PersonBuilder(
//                new FullName.FullNameBuilder(
//                        new Name("Dynamite"), new Name("Napoleon")).createFullName(),
//                new Address.AddressBuilder(
//                        new City("Preston"), State.ID).createAddress()).createPerson();
//    }
//}
