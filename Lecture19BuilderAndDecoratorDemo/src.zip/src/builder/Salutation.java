package builder;

/**
 * Salutations for individuals' names.
 */
public enum Salutation
{
    DR,
    MADAM,
    MISS,
    MR,
    MRS,
    MS,
    SIR
}
