package builder;

public enum EmploymentStatus
{
    EMPLOYED,
    NOT_EMPLOYED
}