package decorator.condiments;

public class Mocha {
}
