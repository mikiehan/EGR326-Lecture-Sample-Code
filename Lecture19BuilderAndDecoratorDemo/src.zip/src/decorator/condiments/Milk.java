package decorator.condiments;
public class Milk  {

}
